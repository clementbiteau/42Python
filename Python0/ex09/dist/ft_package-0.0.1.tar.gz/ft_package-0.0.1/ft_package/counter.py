def count_in_list(lst, item):
    """Regular function that returns the number of items in a selected list."""
    return lst.count(item)