# ft_package
A simple Python package with a function to count occurrences of an item in a list.